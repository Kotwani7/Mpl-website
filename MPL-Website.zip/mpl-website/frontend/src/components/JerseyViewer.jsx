import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

function createShirtShape() {
  const shape = new THREE.Shape();
  shape.moveTo(-0.42, -1.02);
  shape.lineTo(-0.72, -0.18);
  shape.lineTo(-1.22, 0.18);
  shape.lineTo(-0.98, 0.76);
  shape.lineTo(-0.42, 0.56);
  shape.lineTo(-0.24, 0.94);
  shape.lineTo(0.24, 0.94);
  shape.lineTo(0.42, 0.56);
  shape.lineTo(0.98, 0.76);
  shape.lineTo(1.22, 0.18);
  shape.lineTo(0.72, -0.18);
  shape.lineTo(0.42, -1.02);
  shape.closePath();
  return shape;
}

function makeFallbackTexture(team) {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 768;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = team.color || '#d9a21b';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = team.secondaryColor || '#17130d';
  for (let x = -500; x < 900; x += 90) {
    ctx.save(); ctx.translate(x, 0); ctx.rotate(0.38); ctx.fillRect(0, 0, 28, 900); ctx.restore();
  }
  ctx.fillStyle = 'rgba(255,255,255,.12)';
  ctx.fillRect(0, 0, 512, 26);
  ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.font = '900 62px Arial'; ctx.fillText('MPL', 256, 118);
  ctx.fillStyle = team.color || '#d9a21b'; ctx.strokeStyle = '#130f09'; ctx.lineWidth = 7;
  ctx.font = '900 205px Arial'; ctx.strokeText('07', 256, 420); ctx.fillText('07', 256, 420);
  ctx.fillStyle = '#fff'; ctx.font = '700 27px Arial'; ctx.fillText((team.shortName || team.name).toUpperCase(), 256, 500);
  ctx.fillStyle = '#f6d47c'; ctx.font = '700 19px Arial'; ctx.fillText('MAHAKAL PREMIER LEAGUE', 256, 700);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  return texture;
}

function makeBackTexture(team, playerName) {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 768;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = team.secondaryColor || '#17130d'; ctx.fillRect(0, 0, 512, 768);
  ctx.fillStyle = team.color || '#d9a21b'; ctx.fillRect(0, 0, 512, 24); ctx.fillRect(0, 738, 512, 30);
  ctx.fillStyle = 'rgba(255,255,255,.08)';
  for (let x = -500; x < 900; x += 120) { ctx.save(); ctx.translate(x, 0); ctx.rotate(-0.38); ctx.fillRect(0, 0, 18, 900); ctx.restore(); }
  ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.font = '900 52px Arial'; ctx.fillText('MPL', 256, 112);
  ctx.strokeStyle = '#090806'; ctx.lineWidth = 12; ctx.fillStyle = team.color || '#d9a21b';
  ctx.font = '900 250px Arial'; ctx.strokeText('07', 256, 445); ctx.fillText('07', 256, 445);
  ctx.fillStyle = '#fff'; ctx.font = '800 33px Arial'; ctx.fillText((playerName || 'PLAYER 07').toUpperCase().slice(0, 18), 256, 530);
  ctx.fillStyle = '#e8cf8a'; ctx.font = '700 18px Arial'; ctx.fillText('MAHAKAL PREMIER LEAGUE', 256, 680);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  return texture;
}

function createUvShapeGeometry(shape) {
  const geometry = new THREE.ShapeGeometry(shape, 40);
  geometry.computeBoundingBox();
  const { min, max } = geometry.boundingBox;
  const positions = geometry.getAttribute('position');
  const uvs = new Float32Array(positions.count * 2);
  for (let i = 0; i < positions.count; i += 1) {
    const x = positions.getX(i);
    const y = positions.getY(i);
    uvs[i * 2] = (x - min.x) / (max.x - min.x);
    uvs[i * 2 + 1] = (y - min.y) / (max.y - min.y);
    // Slightly rounded chest profile instead of a completely flat card.
    positions.setZ(i, 0.045 - (x * x * 0.035));
  }
  geometry.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  positions.needsUpdate = true;
  geometry.computeVertexNormals();
  return geometry;
}

function addSeam(group, shape) {
  const points = shape.getPoints(80).map((point) => new THREE.Vector3(point.x, point.y, 0.11 - point.x * point.x * 0.035));
  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  const line = new THREE.LineLoop(geometry, new THREE.LineBasicMaterial({ color: '#d8ae4c', transparent: true, opacity: 0.62 }));
  group.add(line);
  return line;
}

export default function JerseyViewer({ team, playerName, designUrl = '' }) {
  const hostRef = useRef(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host || !team) return undefined;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#15120d');
    const camera = new THREE.PerspectiveCamera(34, host.clientWidth / Math.max(host.clientHeight, 1), 0.1, 100);
    camera.position.set(0, 0.05, 5.0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(host.clientWidth, host.clientHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    host.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0xffffff, 1.15));
    const keyLight = new THREE.DirectionalLight(0xffe3ad, 2.6);
    keyLight.position.set(-3, 4, 5); keyLight.castShadow = true; scene.add(keyLight);
    const fillLight = new THREE.DirectionalLight(0xffffff, 1.05);
    fillLight.position.set(3, 0.6, 4); scene.add(fillLight);
    const rimLight = new THREE.PointLight(0xe1a52a, 22, 12);
    rimLight.position.set(2, 1, -2); scene.add(rimLight);

    const group = new THREE.Group();
    group.rotation.y = -0.08;
    scene.add(group);
    const shape = createShirtShape();
    const shellGeometry = new THREE.ExtrudeGeometry(shape, {
      depth: 0.16, bevelEnabled: true, bevelSegments: 4, steps: 1,
      bevelSize: 0.035, bevelThickness: 0.035, curveSegments: 16
    });
    const shellMaterial = new THREE.MeshStandardMaterial({
      color: team.secondaryColor || '#17130d', roughness: 0.9, metalness: 0.01,
      side: THREE.DoubleSide
    });
    const shell = new THREE.Mesh(shellGeometry, shellMaterial);
    shell.position.z = -0.08; shell.castShadow = true; shell.receiveShadow = true;
    group.add(shell);

    const frontGeometry = createUvShapeGeometry(shape);
    const backGeometry = createUvShapeGeometry(shape);
    const fallbackTexture = makeFallbackTexture(team);
    const backTexture = makeBackTexture(team, playerName);
    const frontMaterial = new THREE.MeshStandardMaterial({ map: fallbackTexture, roughness: 0.88, metalness: 0.01, side: THREE.DoubleSide });
    const backMaterial = new THREE.MeshStandardMaterial({ map: backTexture, roughness: 0.88, metalness: 0.01, side: THREE.DoubleSide });
    const front = new THREE.Mesh(frontGeometry, frontMaterial);
    front.position.z = 0.105; front.castShadow = true; front.receiveShadow = true; group.add(front);
    const back = new THREE.Mesh(backGeometry, backMaterial);
    back.rotation.y = Math.PI; back.position.z = -0.105; back.castShadow = true; group.add(back);

    let uploadedTexture = null;
    if (designUrl) {
      uploadedTexture = new THREE.TextureLoader().load(
        designUrl,
        (texture) => {
          texture.colorSpace = THREE.SRGBColorSpace;
          texture.anisotropy = renderer.capabilities.getMaxAnisotropy();
          texture.wrapS = THREE.ClampToEdgeWrapping;
          texture.wrapT = THREE.ClampToEdgeWrapping;
          frontMaterial.map = texture;
          frontMaterial.color.set('#ffffff');
          frontMaterial.needsUpdate = true;
        },
        undefined,
        () => { /* Keep the generated MPL fallback if the saved image is unavailable. */ }
      );
    }

    const seam = addSeam(group, shape);
    const collar = new THREE.Mesh(
      new THREE.TorusGeometry(0.205, 0.042, 12, 48),
      new THREE.MeshStandardMaterial({ color: team.color || '#d9a21b', roughness: 0.5, metalness: 0.12 })
    );
    collar.position.set(0, 0.865, 0.15);
    collar.scale.set(1.18, 0.62, 0.75);
    group.add(collar);

    const ground = new THREE.Mesh(
      new THREE.CircleGeometry(1.35, 64),
      new THREE.MeshBasicMaterial({ color: '#282116', transparent: true, opacity: 0.72 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(0, -1.42, 0);
    ground.scale.set(1.25, 0.38, 1);
    scene.add(ground);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.055;
    controls.enablePan = false;
    controls.minDistance = 3.7;
    controls.maxDistance = 7.2;
    controls.minPolarAngle = 0.72;
    controls.maxPolarAngle = 2.35;

    let animationId = 0;
    const animate = () => {
      animationId = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    const resize = () => {
      const width = host.clientWidth;
      const height = host.clientHeight;
      if (!width || !height) return;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(host);

    return () => {
      cancelAnimationFrame(animationId);
      observer.disconnect();
      controls.dispose();
      shellGeometry.dispose(); shellMaterial.dispose();
      frontGeometry.dispose(); backGeometry.dispose();
      fallbackTexture.dispose(); backTexture.dispose();
      if (uploadedTexture) uploadedTexture.dispose();
      frontMaterial.dispose(); backMaterial.dispose();
      seam.geometry.dispose(); seam.material.dispose();
      collar.geometry.dispose(); collar.material.dispose();
      ground.geometry.dispose(); ground.material.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [team, playerName, designUrl]);

  return <div className="jersey-stage" ref={hostRef}>
    <span className="jersey-stage__hint">DRAG TO ROTATE · SCROLL TO ZOOM</span>
    <span className="jersey-stage__stamp">MPL / OFFICIAL KIT</span>
    {designUrl && <span className="jersey-stage__uploaded">TEAM ARTWORK APPLIED</span>}
  </div>;
}
