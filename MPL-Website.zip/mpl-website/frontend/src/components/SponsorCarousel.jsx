import { useEffect, useState } from 'react';
import { ArrowUpRight, Handshake } from 'lucide-react';

export default function SponsorCarousel({ sponsors = [] }) {
  const [active, setActive] = useState(0);
  useEffect(() => {
    if (sponsors.length < 2) return undefined;
    const timer = window.setInterval(() => setActive((current) => (current + 1) % sponsors.length), 3000);
    return () => window.clearInterval(timer);
  }, [sponsors.length]);
  if (!sponsors.length) return <section className="sponsor-strip sponsor-strip--empty" aria-label="MPL sponsors"><div className="sponsor-strip__label"><Handshake size={15} /> MPL PARTNERS</div><div className="sponsor-carousel"><div className="sponsor-mark">MPL</div><div className="sponsor-copy"><strong>SPONSORS ANNOUNCED SOON</strong><span>Official sponsor names and partner tags will appear here.</span></div></div></section>;
  const sponsor = sponsors[active];
  return <section className="sponsor-strip" aria-label="MPL sponsors">
    <div className="sponsor-strip__label"><Handshake size={15} /> POWERED BY</div>
    <div className="sponsor-carousel" aria-live="polite">
      <div className="sponsor-mark" style={{ '--sponsor-color': sponsor.color || '#d9a21b' }}>{sponsor.initials || sponsor.name.slice(0, 2).toUpperCase()}</div>
      <div className="sponsor-copy" key={sponsor.id}>
        <strong>{sponsor.name}</strong><span>{sponsor.tag}</span>
      </div>
      <span className="sponsor-tier">{sponsor.tier}</span>
      <ArrowUpRight className="sponsor-arrow" size={17} />
    </div>
    <div className="sponsor-dots" aria-label={`Sponsor ${active + 1} of ${sponsors.length}`}>
      {sponsors.map((item, index) => <button key={item.id} className={active === index ? 'is-active' : ''} onClick={() => setActive(index)} aria-label={`Show ${item.name}`} />)}
    </div>
  </section>;
}
