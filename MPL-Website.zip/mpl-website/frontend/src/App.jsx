import { useEffect, useMemo, useState } from 'react';
import {
  ArrowDown, ArrowRight, ArrowUpRight, Award, CalendarDays, ChevronDown, ChevronLeft,
  ChevronRight, CircleDot, Instagram, Menu, Shield, ShieldCheck, Trophy, Users, Youtube, X,
  Zap, Target, Activity, MapPin, Clock3, Medal, BarChart3, Sparkles
} from 'lucide-react';
import SectionHeading from './components/SectionHeading';
import SponsorCarousel from './components/SponsorCarousel';
import JerseyViewer from './components/JerseyViewer';
import RegistrationForm from './components/RegistrationForm';
import AuctionRoom from './components/AuctionRoom';
import { api } from './lib/api';

const metrics = [
  { id: 'mostRuns', label: 'Most Runs', short: 'RUNS', icon: Target, unit: 'runs' },
  { id: 'mostWickets', label: 'Most Wickets', short: 'WICKETS', icon: Zap, unit: 'wkts' },
  { id: 'mostDotBalls', label: 'Most Dot Balls', short: 'DOT BALLS', icon: CircleDot, unit: 'dots' },
  { id: 'mvp', label: 'MVP', short: 'MVP', icon: Award, unit: 'awards' }
];
const navItems = [
  ['home', 'Home'], ['tournaments', 'Tournaments'], ['league', 'League Hub'], ['leaderboards', 'Leaderboards'], ['auction', 'Auction'], ['jerseys', 'Jerseys'], ['register', 'Register']
];

function useLeagueData() {
  const [data, setData] = useState({ site: null, sponsors: [], tournaments: [], teams: [], players: [], matches: [], standings: [], jerseys: [] });
  const [health, setHealth] = useState(null);
  const [connection, setConnection] = useState('checking');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [retryCount, setRetryCount] = useState(0);

  useEffect(() => {
    let alive = true;
    let timer = null;
    const load = async () => {
      let nextDelay = 30000;
      setError('');
      setConnection((current) => current === 'connected' ? current : 'checking');
      try {
        const [healthData, siteData, teams, players, matches, standings, jerseys] = await Promise.all([
          api.health(), api.site(), api.teams(), api.players(), api.matches(), api.standings(), api.jerseys()
        ]);
        if (healthData?.status !== 'ok' || healthData?.database !== 'connected') {
          throw new Error('The MPL API responded, but the SQLite database did not pass its connection check.');
        }
        if (alive) {
          setHealth(healthData);
          setData({ site: siteData.site, sponsors: siteData.sponsors, tournaments: siteData.tournaments, teams, players, matches, standings, jerseys });
          setConnection('connected');
        }
      } catch (e) {
        nextDelay = 5000;
        if (alive) {
          setConnection('error');
          setError(e.message || 'Unable to connect to the MPL database.');
        }
      } finally {
        if (alive) {
          setLoading(false);
          timer = window.setTimeout(load, nextDelay);
        }
      }
    };
    load();
    return () => { alive = false; if (timer) window.clearTimeout(timer); };
  }, [retryCount]);

  const saveJersey = (jersey) => setData((current) => ({ ...current, jerseys: [...current.jerseys.filter((item) => item.teamId !== jersey.teamId), jersey] }));
  return { data, error, loading, health, connection, retry: () => setRetryCount((value) => value + 1), saveJersey };
}

function DatabaseConnectionStatus({ connection, health, onRetry }) {
  const connected = connection === 'connected';
  const label = connected
    ? `DATABASE CONNECTED · ${health?.counts?.players ?? 0} PLAYERS · ${health?.counts?.teams ?? 0} TEAMS · ${health?.counts?.matches ?? 0} MATCHES`
    : connection === 'checking' ? 'CONNECTING TO MPL DATABASE…' : 'DATABASE DISCONNECTED';
  return <div className={`database-status database-status--${connection}`} role="status" aria-live="polite">
    <span className="database-status__dot" />
    <span>{label}</span>
    {!connected && connection === 'error' && <button type="button" onClick={onRetry}>RETRY CONNECTION</button>}
  </div>;
}

function Header() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('home');
  useEffect(() => {
    const ids = navItems.map(([id]) => document.getElementById(id)).filter(Boolean);
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (visible) setActive(visible.target.id);
    }, { rootMargin: '-30% 0px -55% 0px', threshold: [0, 0.15, 0.35] });
    ids.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
  const goTo = (id) => { document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' }); setOpen(false); };
  return <header className="site-header">
    <div className="header-inner">
      <button className="brand-lockup" onClick={() => goTo('home')} aria-label="MPL home">
        <span className="brand-emblem"><span>M</span></span><span className="brand-word">MAHAKAL <b>PREMIER LEAGUE</b></span>
      </button>
      <nav className={`main-nav ${open ? 'main-nav--open' : ''}`}>
        {navItems.map(([id, label]) => <button key={id} className={active === id ? 'nav-link is-active' : 'nav-link'} onClick={() => goTo(id)}>{label}</button>)}
      </nav>
      <button className="header-cta" onClick={() => goTo('register')}>JOIN THE LEAGUE <ArrowUpRight size={15} /></button>
      <button className="mobile-menu" aria-label={open ? 'Close menu' : 'Open menu'} onClick={() => setOpen((v) => !v)}>{open ? <X /> : <Menu />}</button>
    </div>
  </header>;
}

function Hero({ site }) {
  return <section className="hero section-shell" id="home">
    <div className="hero-grid">
      <div className="hero-copy">
        <div className="hero-kicker"><span className="live-dot" /> OPEN FOR ALL · SEASON 2 / 2027</div>
        <h1>THE GAME<br /><span>HAS NO</span> <em>LIMITS.</em></h1>
        <p>{site?.tagline || 'One league. Two formats. Unlimited passion.'} Bring your team, bring your energy and make your mark in the Mahakal Premier League.</p>
        <div className="hero-actions"><a className="button button--gold" href="#register">Register to play <ArrowUpRight size={17} /></a><a className="button button--ghost" href="#league">Explore the league <ArrowDown size={16} /></a></div>
        <div className="hero-footnote"><span>01 / 02 FORMATS</span><span className="hero-line" /><span>OPEN GROUND + TURF</span></div>
      </div>
      <div className="hero-art">
        <div className="hero-art__halo" />
        <div className="hero-logo-card"><img src="/assets/mpl-season-2.png" alt="Mahakal Premier League Season 2, 2027 logo" /></div>
        <div className="hero-season-tag"><span>THE NEXT CHAPTER</span><strong>2027</strong><small>SEASON TWO</small></div>
        <div className="hero-orbit hero-orbit--one" /><div className="hero-orbit hero-orbit--two" />
      </div>
    </div>
    <div className="hero-bottom-bar"><span><ShieldCheck size={16} /> OPEN TO ALL PLAYERS</span><span><CalendarDays size={16} /> TOURNAMENTS THROUGHOUT THE YEAR</span><span><Trophy size={16} /> EARN YOUR PLACE IN MPL HISTORY</span></div>
  </section>;
}

function TournamentCards({ tournaments = [] }) {
  const ground = tournaments.find((t) => t.type === 'ground');
  const turf = tournaments.find((t) => t.type === 'turf');
  const cards = [
    { type: 'ground', number: '01', title: 'OPEN GROUND', subtitle: 'THE CLASSIC FORMAT', desc: ground?.description || 'Full-ground cricket. Big boundaries. Bigger moments. Build your squad and compete for the title.', overs: ground?.overs, teamSize: ground?.teamSize || 'Squad size to be announced', venue: 'Outdoor grounds', style: 'ground' },
    { type: 'turf', number: '02', title: 'TURF LEAGUE', subtitle: 'THE FAST FORMAT', desc: turf?.description || 'Quick, intense and made for the turf. Short-format cricket where every delivery can change the game.', overs: turf?.overs, teamSize: turf?.teamSize || 'Squad size to be announced', venue: 'Turf arenas', style: 'turf' }
  ];
  return <div className="tournament-grid">{cards.map((card) => <article className={`tournament-card tournament-card--${card.style}`} key={card.type}>
    <div className="tournament-card__top"><span>FORMAT {card.number}</span><span className="status-pill"><i /> REGISTRATION OPEN</span></div>
    <div className="format-illustration"><div className="format-circle"><span>{card.overs ? `${card.overs}` : 'TBA'}</span><small>{card.overs ? 'OVERS' : 'FORMAT'}</small></div><div className="format-graphic"><span /><span /><span /></div></div>
    <span className="eyebrow">{card.subtitle}</span><h3>{card.title}</h3><p>{card.desc}</p>
    <div className="tournament-facts"><span><Clock3 size={15} /> {card.overs ? `${card.overs} overs` : 'Overs TBA'}</span><span><Users size={15} /> {card.teamSize}</span><span><MapPin size={15} /> {card.venue}</span></div>
    <a className="text-link" href="#register">Enter this format <ArrowRight size={16} /></a>
  </article>)}</div>;
}

function MatchCard({ match }) {
  const date = new Date(`${match.date}T${match.time || '00:00'}:00`);
  const dateText = Number.isNaN(date.getTime()) ? match.date : date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
  const timeText = Number.isNaN(date.getTime()) ? match.time : date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  return <article className="match-card">
    <div className="match-meta"><span>MATCH {String(match.matchNo).padStart(2, '0')}</span><span className={`match-state match-state--${match.status}`}>{match.status === 'completed' ? 'RESULT' : 'UPCOMING'}</span></div>
    <div className="match-teams">
      <div className="match-team"><span className="team-mini-mark" style={{ '--team-color': match.teamA?.color }}>{match.teamA?.shortName || 'TBD'}</span><strong>{match.teamA?.name || 'Team TBA'}</strong><small>{match.scoreA || 'READY TO PLAY'}</small></div>
      <span className="versus">VS</span>
      <div className="match-team match-team--right"><span className="team-mini-mark" style={{ '--team-color': match.teamB?.color }}>{match.teamB?.shortName || 'TBD'}</span><strong>{match.teamB?.name || 'Team TBA'}</strong><small>{match.scoreB || 'READY TO PLAY'}</small></div>
    </div>
    <div className="match-bottom"><span><CalendarDays size={14} /> {dateText} · {timeText}</span><span><MapPin size={14} /> {match.venue}</span></div>
    {match.result && <div className="match-result">{match.result}</div>}
  </article>;
}

function TeamCards({ teams = [] }) {
  return <div className="team-grid">{teams.map((team) => <article className="team-card" key={team.id}>
    <div className="team-card__top" style={{ '--team-color': team.color, '--team-secondary': team.secondaryColor }}><span className="team-crest">{team.shortName}</span><span className="team-year">EST. {team.founded || 2026}</span></div>
    <div className="team-card__body"><div><h4>{team.name}</h4><span className="team-city"><MapPin size={12} /> {team.city || 'Season 1 squad'}</span></div><div className="team-captain"><small>CAPTAIN</small><strong>{team.captain || 'To be announced'}</strong><small className="team-record">{team.won || 0}W · {team.lost || 0}L · {team.points || 0} PTS</small></div></div>
  </article>)}</div>;
}

function PlayerCards({ players = [], teams = [], onSelect }) {
  const teamMap = new Map(teams.map((team) => [team.id, team]));
  return <div className="player-grid">{players.map((player, index) => {
    const team = teamMap.get(player.teamId);
    return <button className="player-card" key={player.id} onClick={() => onSelect(player)} aria-label={`View ${player.name} player profile`}><div className="player-card__number">{String(player.jerseyNumber || index + 1).padStart(2, '0')}</div><div className="player-avatar" style={{ '--team-color': team?.color || '#d9a21b' }}>{player.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}</div><div className="player-card__info"><strong>{player.name}</strong><span>{team?.name || 'MPL Player'}</span><small>{player.role} · VIEW PROFILE</small></div><div className="player-mini-stats"><span><b>{player.runs}</b><small>RUNS</small></span><span><b>{player.wickets}</b><small>WKTS</small></span></div></button>;
  })}</div>;
}

function PlayerProfile({ player, teams, onClose }) {
  if (!player) return null;
  const team = teams.find((item) => item.id === player.teamId);
  const stats = [['MATCHES', player.matches], ['RUNS', player.runs], ['WICKETS', player.wickets], ['DOT BALLS', player.dotBalls], ['STRIKE RATE', player.strikeRate], ['AVERAGE', player.average], ['ECONOMY', player.economy], ['MVP AWARDS', player.mvp]];
  return <div className="profile-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className="profile-modal" role="dialog" aria-modal="true" aria-labelledby="profile-title"><button className="profile-close" onClick={onClose} aria-label="Close player profile"><X size={18} /></button><span className="eyebrow">MPL PLAYER CARD</span><div className="profile-identity"><div className="profile-avatar" style={{ '--team-color': team?.color || '#d9a21b' }}>{player.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}</div><div><h3 id="profile-title">{player.name}</h3><p>{team?.name || 'MPL Player'} · {player.role}</p></div></div><div className="profile-meta"><span>JERSEY <b>#{player.jerseyNumber || '—'}</b></span><span>AGE <b>{player.age || '—'}</b></span><span>FORMAT <b>{player.type === 'turf' ? 'TURF' : 'GROUND'}</b></span></div><div className="profile-stats">{stats.map(([label, value]) => <div key={label}><span>{label}</span><strong>{value ?? 0}</strong></div>)}</div><p className="profile-footnote">Season 1 figures are aggregated from the uploaded CricHeroes scorecards. MVP awards were not included in the source scorecards.</p></section></div>;
}

function StandingsTable({ standings = [] }) {
  return <div className="table-wrap"><table className="standings-table"><thead><tr><th>POS</th><th>TEAM</th><th>PLAYED</th><th>W</th><th>L</th><th>PTS</th><th>NRR</th></tr></thead><tbody>{standings.map((team, index) => <tr key={team.id}><td><span className={`rank-number ${index === 0 ? 'rank-number--gold' : ''}`}>{String(team.rank || index + 1).padStart(2, '0')}</span></td><td><span className="table-team"><i style={{ background: team.color }} />{team.name}</span></td><td>{team.played}</td><td>{team.won}</td><td>{team.lost}</td><td className="points-cell">{team.points}</td><td>{team.nrr == null ? '—' : Number(team.nrr).toFixed(2)}</td></tr>)}</tbody></table>{standings.length === 0 && <div className="empty-state">Standings will appear when teams and results are added.</div>}</div>;
}

function LeagueHub({ data, loading }) {
  const [format, setFormat] = useState('ground');
  const [view, setView] = useState('matches');
  const [showAll, setShowAll] = useState(false);
  const [selectedPlayer, setSelectedPlayer] = useState(null);
  const teams = data.teams.filter((t) => t.type === format);
  const players = data.players.filter((p) => p.type === format);
  const matches = data.matches.filter((m) => m.type === format);
  const standings = data.standings.filter((t) => t.type === format);
  const tabs = [{ id: 'matches', label: 'Matches', icon: CalendarDays }, { id: 'players', label: 'Players', icon: Users }, { id: 'teams', label: 'Teams', icon: Shield }, { id: 'table', label: 'Season table', icon: BarChart3 }];
  return <section className="league-section section-shell" id="league">
    <SectionHeading eyebrow="FOLLOW EVERY DELIVERY" title={<>THE LEAGUE <em>HUB.</em></>} description="Fixtures, team profiles, player cards and season standings. Everything in one place." />
    <div className="league-console">
      <div className="league-console__head"><div className="format-switch"><button className={format === 'ground' ? 'is-selected' : ''} onClick={() => setFormat('ground')}><span className="switch-icon">OG</span> OPEN GROUND</button><button className={format === 'turf' ? 'is-selected' : ''} onClick={() => setFormat('turf')}><span className="switch-icon">TF</span> TURF</button></div><div className="season-label"><span className="live-dot" /> {format === 'ground' ? 'SEASON 1 HISTORY · 2026' : 'SEASON 2 FORMAT · 2027'}</div></div>
      <div className="league-console__body">
        <div className="console-sidebar"><span className="console-sidebar__label">LEAGUE CENTRE</span>{tabs.map(({ id, label, icon: Icon }) => <button key={id} className={view === id ? 'console-tab is-selected' : 'console-tab'} onClick={() => { setView(id); setShowAll(false); }}><Icon size={17} /> {label}<ChevronRight size={15} /></button>)}<div className="console-sidebar__note"><Trophy size={22} /><strong>CHASE THE<br />MPL TITLE.</strong><span>Every run counts.<br />Every player matters.</span></div></div>
        <div className="console-content">
          <div className="console-content__head"><div><span className="eyebrow">{format === 'ground' ? 'OPEN GROUND SERIES' : 'TURF SERIES'}</span><h3>{tabs.find((t) => t.id === view)?.label}</h3></div><span className="count-tag">{view === 'matches' ? `${matches.length} FIXTURES` : view === 'players' ? `${players.length} PLAYERS` : view === 'teams' ? `${teams.length} TEAMS` : `${standings.length} TEAMS`}</span></div>
          {loading ? <div className="empty-state">Loading league data...</div> : <>
            {view === 'matches' && <div className="match-list">{(showAll ? matches : matches.slice(0, 4)).map((m) => <MatchCard key={m.id} match={m} />)}{matches.length === 0 && <div className="empty-state">Fixtures will be published here.</div>}</div>}
            {view === 'players' && <PlayerCards players={players} teams={teams} onSelect={setSelectedPlayer} />}
            {view === 'teams' && <TeamCards teams={teams} />}
            {view === 'table' && <StandingsTable standings={standings} />}
            {view === 'matches' && matches.length > 4 && <button className="view-more" onClick={() => setShowAll((v) => !v)}>{showAll ? 'SHOW LESS' : 'VIEW ALL FIXTURES'} <ChevronDown size={15} className={showAll ? 'rotate-up' : ''} /></button>}
          </>}
        </div>
      </div>
    </div>
    <PlayerProfile player={selectedPlayer} teams={data.teams} onClose={() => setSelectedPlayer(null)} />
  </section>;
}

function Leaderboards({ teams, players }) {
  const [format, setFormat] = useState('overall');
  const [metric, setMetric] = useState('mostRuns');
  const filtered = players.filter((p) => format === 'overall' || p.type === format);
  const ranked = useMemo(() => {
    const key = metrics.find((m) => m.id === metric)?.unit;
    const prop = metric === 'mostRuns' ? 'runs' : metric === 'mostWickets' ? 'wickets' : metric === 'mostDotBalls' ? 'dotBalls' : 'mvp';
    if (metric === 'mvp' && !filtered.some((player) => player.mvpRecorded)) return [];
    return [...filtered].sort((a, b) => (b[prop] || 0) - (a[prop] || 0)).slice(0, 8);
  }, [filtered, metric]);
  const teamMap = new Map(teams.map((team) => [team.id, team]));
  const selectedMetric = metrics.find((m) => m.id === metric);
  return <section className="leaderboard-section section-shell" id="leaderboards">
    <SectionHeading eyebrow="NUMBERS NEVER LIE" title={<>BUILT ON <em>PERFORMANCE.</em></>} description="Individual honours across both tournament formats. The leaderboard updates with match statistics." />
    <div className="leaderboard-panel">
      <div className="leaderboard-panel__head"><div className="leaderboard-selects"><div className="format-pills"><button className={format === 'overall' ? 'is-selected' : ''} onClick={() => setFormat('overall')}>OVERALL</button><button className={format === 'ground' ? 'is-selected' : ''} onClick={() => setFormat('ground')}>GROUND</button><button className={format === 'turf' ? 'is-selected' : ''} onClick={() => setFormat('turf')}>TURF</button></div></div><span className="leaderboard-updated"><Activity size={14} /> SEASON 1 HISTORICAL STATS</span></div>
      <div className="metric-tabs">{metrics.map(({ id, label, icon: Icon }) => <button key={id} className={metric === id ? 'metric-tab is-selected' : 'metric-tab'} onClick={() => setMetric(id)}><Icon size={17} /><span>{label}</span></button>)}</div>
      <div className="leaderboard-table-head"><span>RANK / PLAYER</span><span>TEAM</span><span>{selectedMetric?.short || 'STAT'}</span></div>
      <div className="leaderboard-rows">{ranked.map((player, index) => {
        const team = teamMap.get(player.teamId); const value = player[metric === 'mostRuns' ? 'runs' : metric === 'mostWickets' ? 'wickets' : metric === 'mostDotBalls' ? 'dotBalls' : 'mvp'];
        return <div className={`leaderboard-row ${index === 0 ? 'leaderboard-row--top' : ''}`} key={player.id}><div className="leader-player"><span className="leader-rank">{String(index + 1).padStart(2, '0')}</span><span className="leader-avatar" style={{ '--team-color': team?.color || '#d9a21b' }}>{player.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}</span><span><strong>{player.name}</strong><small>{player.role} · {player.matches} matches</small></span></div><div className="leader-team"><i style={{ background: team?.color || '#d9a21b' }} />{team?.name || 'MPL'}</div><strong className="leader-value">{value ?? 0}<small>{metric === 'mvp' ? 'MVP' : selectedMetric?.unit}</small></strong></div>;
      })}{ranked.length === 0 && <div className="empty-state">{metric === 'mvp' ? 'MVP award records were not included in the Season 1 source scorecards.' : 'Player statistics will show here.'}</div>}</div>
      <div className="leaderboard-foot"><span><Medal size={16} /> TOP PERFORMERS · SEASON 1</span><span>MVP awards were not listed in the source scorecards.</span></div>
    </div>
  </section>;
}

function Jerseys({ teams, jerseys = [], onJerseySaved }) {
  const [selectedId, setSelectedId] = useState('g-mahakal-strikers');
  const [sampleName, setSampleName] = useState('PLAYER 07');
  const [adminKey, setAdminKey] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadMessage, setUploadMessage] = useState('');
  const [uploadError, setUploadError] = useState('');
  const selected = teams.find((team) => team.id === selectedId) || teams[0];
  const selectedJersey = jerseys.find((jersey) => jersey.teamId === selected?.id);
  useEffect(() => { if (teams.length && !teams.some((t) => t.id === selectedId)) setSelectedId(teams[0].id); }, [teams, selectedId]);
  const handleJerseyUpload = (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    setUploadMessage(''); setUploadError('');
    if (!file || !selected) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) { setUploadError('Choose a PNG, JPG or WebP image.'); return; }
    if (file.size > 4 * 1024 * 1024) { setUploadError('The image must be 4 MB or smaller.'); return; }
    if (!adminKey.trim()) { setUploadError('Enter the organiser key before uploading.'); return; }
    setUploading(true);
    const reader = new FileReader();
    reader.onerror = () => { setUploading(false); setUploadError('The selected image could not be read.'); };
    reader.onload = async () => {
      try {
        const result = await api.uploadTeamJersey(selected.id, { fileName: file.name, mimeType: file.type, dataUrl: String(reader.result) }, adminKey.trim());
        onJerseySaved?.(result.jersey);
        setUploadMessage(`${file.name} saved for ${selected.name}.`);
      } catch (error) { setUploadError(error.message || 'Jersey upload failed.'); }
      finally { setUploading(false); }
    };
    reader.readAsDataURL(file);
  };
  return <section className="jersey-section section-shell" id="jerseys">
    <div className="jersey-heading"><SectionHeading eyebrow="WEAR YOUR COLOURS" title={<>THE MPL <em>KIT ROOM.</em></>} description="Explore the team kits in 3D. Drag to rotate the jersey and scroll to zoom in." /><span className="edition-tag">2027 / OFFICIAL COLLECTION</span></div>
    <div className="jersey-layout">
      <div className="jersey-stage-wrap">{selected ? <JerseyViewer team={selected} playerName={sampleName} designUrl={selectedJersey?.imageUrl || ''} /> : <div className="empty-state">Add teams to display their kits.</div>}<div className="jersey-stage-footer"><span><Sparkles size={15} /> INTERACTIVE 3D PREVIEW</span><span>360° VIEW</span></div></div>
      <div className="jersey-detail"><span className="eyebrow">SELECT YOUR SIDE</span><h3>{selected?.name || 'MPL TEAM'}</h3><p className="jersey-detail__desc">Official match-day colourway for the {selected?.type === 'turf' ? 'turf' : 'open ground'} tournament. Team colours and player details are configurable.</p>
        <div className="jersey-colour"><span>TEAM COLOURS</span><span className="colour-swatches"><i style={{ background: selected?.color }} /><i style={{ background: selected?.secondaryColor }} /></span></div>
        <label className="kit-select-label">CHOOSE TEAM<select value={selected?.id || ''} onChange={(e) => setSelectedId(e.target.value)}>{teams.map((team) => <option key={team.id} value={team.id}>{team.name} · {team.type === 'ground' ? 'Ground' : 'Turf'}</option>)}</select></label>
        <label className="kit-select-label">PREVIEW NAME<input value={sampleName} maxLength="18" onChange={(e) => setSampleName(e.target.value || 'PLAYER 07')} /></label>
        <div className="jersey-upload-panel">
          <span className="eyebrow">OFFICIAL KIT ARTWORK</span>
          <label className="kit-select-label">ORGANISER ACCESS KEY<input type="password" autoComplete="off" value={adminKey} onChange={(e) => setAdminKey(e.target.value)} placeholder="Enter organiser key" /></label>
          <label className={`jersey-upload-button ${uploading || !adminKey.trim() ? 'is-disabled' : ''}`}>
            <span>{uploading ? 'SAVING JERSEY…' : selectedJersey ? 'REPLACE TEAM JERSEY' : 'UPLOAD TEAM JERSEY'}</span>
            <input type="file" accept="image/png,image/jpeg,image/webp" disabled={uploading || !adminKey.trim()} onChange={handleJerseyUpload} />
          </label>
          <p className="jersey-upload-note">PNG, JPG or WebP · maximum 4 MB. A transparent PNG or tightly cropped, front-facing jersey artwork gives the cleanest 3D result. The image is saved on the backend and linked to this team.</p>
          {selectedJersey && <span className="jersey-upload-status">CURRENT ARTWORK: {selectedJersey.originalName}</span>}
          {uploadMessage && <span className="jersey-upload-success">{uploadMessage}</span>}
          {uploadError && <span className="jersey-upload-error" role="alert">{uploadError}</span>}
        </div>
        <div className="jersey-specs"><div><span>LEAGUE</span><strong>MAHAKAL PREMIER LEAGUE</strong></div><div><span>EDITION</span><strong>SEASON 2 / 2027</strong></div><div><span>FORMAT</span><strong>{selected?.type === 'turf' ? 'TURF' : 'OPEN GROUND'}</strong></div></div>
        <a className="button button--gold jersey-register" href="#register">Register for your team <ArrowUpRight size={16} /></a>
      </div>
    </div>
  </section>;
}

function Registration({ site }) {
  return <section className="registration-section section-shell" id="register">
    <div className="registration-top"><div><span className="eyebrow"><i /> YOUR TURN TO PLAY</span><h2>STEP ONTO<br /><em>THE FIELD.</em></h2><p>Open to passionate players. Tell us how you play, choose your format and submit your interest. The MPL team will take it from there.</p><div className="registration-points"><span><CheckMark /> Open to all</span><span><CheckMark /> Ground + Turf</span><span><CheckMark /> Individual entries welcome</span></div></div>
      <div className="registration-seal"><img src="/assets/mpl-season-1.png" alt="MPL Season 1 logo" /><span>THE LEAGUE<br />CALLS YOU</span></div>
    </div>
    <div className="registration-main"><div className="registration-form-title"><span className="eyebrow">PLAYER ENTRY</span><h3>REGISTRATION <em>FORM.</em></h3><p>Fields marked required must be completed.</p></div><RegistrationForm /></div>
    <div className="contact-row"><div><span className="eyebrow">STAY IN THE LOOP</span><h3>FOLLOW THE <em>LEAGUE.</em></h3></div><div className="social-links">
      {site?.socials?.instagram && <a href={site.socials.instagram} target="_blank" rel="noreferrer"><Instagram size={17} /> Instagram <ArrowUpRight size={14} /></a>}
      {site?.socials?.youtube && <a href={site.socials.youtube} target="_blank" rel="noreferrer"><Youtube size={18} /> YouTube <ArrowUpRight size={14} /></a>}
      {site?.socials?.whatsapp && <a href={site.socials.whatsapp} target="_blank" rel="noreferrer"><Users size={17} /> WhatsApp <ArrowUpRight size={14} /></a>}
      {!site?.socials?.instagram && !site?.socials?.youtube && !site?.socials?.whatsapp && <span className="social-pending">Official social links will be announced here.</span>}
    </div></div>
  </section>;
}
function CheckMark() { return <span className="check-mark">✓</span>; }

function Footer({ site }) {
  return <footer className="site-footer"><div className="footer-main"><div className="footer-brand"><div className="brand-lockup brand-lockup--footer"><span className="brand-emblem"><span>M</span></span><span className="brand-word">MAHAKAL <b>PREMIER LEAGUE</b></span></div><p>{site?.tagline || 'One league. Two formats. Unlimited passion.'}</p></div><div className="footer-nav"><span>EXPLORE</span><a href="#tournaments">Tournaments</a><a href="#league">League hub</a><a href="#leaderboards">Leaderboards</a><a href="#auction">Player auction</a><a href="#jerseys">Team jerseys</a></div><div className="footer-nav"><span>CONTACT</span>{site?.contactEmail ? <a href={`mailto:${site.contactEmail}`}>{site.contactEmail}</a> : <span>Contact email to be announced</span>}{site?.contactPhone ? <a href={`tel:${site.contactPhone}`}>{site.contactPhone}</a> : <span>Contact number to be announced</span>}</div><div className="footer-mark"><img src="/assets/mpl-season-2.png" alt="MPL season 2 crest" /></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} MAHAKAL PREMIER LEAGUE. ALL RIGHTS RESERVED.</span><span>BUILT FOR THE LOVE OF THE GAME.</span></div></footer>;
}

export default function App() {
  const { data, error, loading, health, connection, retry, saveJersey } = useLeagueData();
  const [showTop, setShowTop] = useState(false);
  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 700);
    window.addEventListener('scroll', onScroll, { passive: true }); return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return <>
    <Header />
    <DatabaseConnectionStatus connection={connection} health={health} onRetry={retry} />
    <main>
      <Hero site={data.site} />
      <SponsorCarousel sponsors={data.sponsors} />
      <section className="tournament-section section-shell" id="tournaments">
        <SectionHeading eyebrow="TWO WAYS TO PLAY" title={<>ONE LEAGUE. <em>TWO BATTLEGROUNDS.</em></>} description="MPL hosts open-for-all tournaments at scheduled intervals. Pick your format, build your squad and get in the game." />
        <TournamentCards tournaments={data.tournaments} />
      </section>
      <LeagueHub data={data} loading={loading} />
      <Leaderboards teams={data.teams} players={data.players} />
      <AuctionRoom />
      <Jerseys teams={data.teams} jerseys={data.jerseys} onJerseySaved={saveJersey} />
      <Registration site={data.site} />
      <Footer site={data.site} />
    </main>
    {error && <div className="api-notice" role="status"><span className="api-notice__dot" /> API connection issue: {error} <small>Start the backend to load live league data.</small></div>}
    {showTop && <button className="back-to-top" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} aria-label="Back to top"><ChevronLeft size={18} /></button>}
  </>;
}
